#include <Layer/ImGuiAPI.h>
#include <imgui.h>
#include <imgui_impl_metal.h>
#include <View/ViewAdapter.hpp>
#include <View/ViewExtender.h>


// Set up IMGUI
// https://github.com/ocornut/imgui/blob/master/examples/example_apple_metal/main.mm
void initialize_imgui(MTL::Device* device) {
  DEBUG("Initializing ImGui ...");
  IMGUI_CHECKVERSION();
  ImGui::CreateContext();
  ImGui::StyleColorsDark();
  ImGui_ImplMetal_Init((__bridge id<MTLDevice>)device);
}


void deallocate_imgui() {
  ImGui_ImplMetal_Shutdown();
  ImGui::DestroyContext();
}


void imgui_on_update(
	MTK::View* view, 
	MTL::CommandQueue* queue,
	MTL::RenderCommandEncoder* encoder
) {

  ImGuiIO& io = ImGui::GetIO();
  CGRect frame = EXP::ViewAdapter::bounds();

  io.DisplaySize.x = frame.size.width;
  io.DisplaySize.y = frame.size.height;
  io.DisplayFramebufferScale =
      ImVec2(NSScreen.mainScreen.backingScaleFactor, NSScreen.mainScreen.backingScaleFactor);

  ImGui_ImplMetal_NewFrame((__bridge MTLRenderPassDescriptor*)view->currentRenderPassDescriptor());
  ImGui::NewFrame();

  static bool showDemo = true;
  show_imgui_debug_window(&showDemo);
  ImGui::Render();

  ImDrawData* drawData = ImGui::GetDrawData();
  ImGui_ImplMetal_RenderDrawData(
      drawData, 
			(__bridge id<MTLCommandBuffer>)queue->commandBuffer(), 
			(__bridge id<MTLRenderCommandEncoder>)encoder
  );
}


void show_imgui_debug_window(bool* open) {

  static int location = 0;
  ImGuiIO& io = ImGui::GetIO();
  ImGuiWindowFlags window_flags = ImGuiWindowFlags_NoDecoration |
                                  ImGuiWindowFlags_AlwaysAutoResize |
                                  ImGuiWindowFlags_NoSavedSettings |
                                  ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav;
  const float PAD = 10.0f;
  const ImGuiViewport* viewport = ImGui::GetMainViewport();
  ImVec2 work_pos = viewport->WorkPos;
  ImVec2 work_size = viewport->WorkSize;
  ImVec2 window_pos, window_pos_pivot;
  window_pos.x = (location & 1) ? (work_pos.x + work_size.x - PAD) : (work_pos.x + PAD);
  window_pos.y = (location & 2) ? (work_pos.y + work_size.y - PAD) : (work_pos.y + PAD);
  window_pos_pivot.x = (location & 1) ? 1.0f : 0.0f;
  window_pos_pivot.y = (location & 2) ? 1.0f : 0.0f;
  ImGui::SetNextWindowPos(window_pos, ImGuiCond_Always, window_pos_pivot);
  window_flags |= ImGuiWindowFlags_NoMove;
  ImGui::SetNextWindowBgAlpha(0.80f);

  if (ImGui::Begin("DBWindow", open, window_flags)) {
    ImGui::Text("//// Debug information ////");
    ImGui::Separator();
    if (ImGui::IsMousePosValid()) ImGui::Text("Mouse: (%.1f,%.1f)", io.MousePos.x, io.MousePos.y);
  }
  ImGui::End();
}

