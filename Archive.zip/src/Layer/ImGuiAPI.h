#pragma once
#include <pch.h>


void initialize_imgui(MTL::Device* view); 
void deallocate_imgui();
void imgui_on_update(
	MTK::View* view, 
	MTL::CommandBuffer* queue,
	MTL::RenderCommandEncoder* encoder,
	MTL::Texture* drawable
);
void show_imgui_debug_window(bool* open); 


