#pragma once
#include "Metal/MTLAccelerationStructure.hpp"
#include "Metal/MTLComputePipeline.hpp"
#include "Metal/MTLVertexDescriptor.hpp"
#include <Layer/Layer.h>
#include <Model/Camera.h>
#include <Model/MeshFactory.h>
#include <Model/ResourceManager.h>
#include <pch.h>

namespace EXP {

class RayTraceLayer : public Layer {

public: // Setting up layer
  RayTraceLayer(MTL::Device* device, std::shared_ptr<const AppProperties> config);
  ~RayTraceLayer(); 
public: // Event
  void buildModels(MTL::Device* device);
  void buildAccelerationStructures(MTL::Device* device);
	void rebuildAccelerationStructures(MTK::View* device);
	MTL::Size calcGridsize(const MTL::ComputePipelineState* state);

private: // Initialization
  virtual void onUpdate(MTK::View* view, MTL::RenderCommandEncoder* encoder) override;

private:
  MTL::Device* device;
	MTL::Function* _kernelFn;
	MTL::ComputePipelineState* _gbufferState;
	MTL::ComputePipelineState* _temporalReuseState;
  MTL::ComputePipelineState* _raytraceState;

private:
  MTL::CommandQueue* queue;

  MTL::Size _threadGroupSize;
  MTL::Size _gridSize;
  simd::float3 _resolution;

private:
	MTL::VertexDescriptor* _vertexDescriptor;

private:
	MTL::Event* _buildEvent;
	MTL::Event* _dispatchEvent;
  MTL::Heap* _heap;

private:
	std::vector<MTL::PrimitiveAccelerationStructureDescriptor*> _primitiveDescriptors;
	std::vector<MTL::AccelerationStructure*> _primitiveAccStructures;

private:
	MTL::InstanceAccelerationStructureDescriptor* _instanceDescriptor;
  MTL::InstanceAccelerationStructureDescriptor* _instanceRefitDescriptor;
  MTL::AccelerationStructure* _instanceAccStructure;
  MTL::AccelerationStructureSizes _instanceSizes;
  MTL::Buffer* _scratchBuffer;

private:
  MTL::ComputePassDescriptor* _temporalDescriptor;

private:
	int t = 0;

private:
    MTL::Texture* _outputTexture;
};
}; // namespace EXP
